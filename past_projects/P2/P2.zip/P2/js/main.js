// **** Your JavaScript code goes here ****
//NOTE: this is the D3 v4 loading syntax. For more details, see https://piazza.com/class/jnzgy0ktwi34lk?cid=75.
d3.csv("./data/coffee_data.csv", function(data){

	console.log(data[0]);
})